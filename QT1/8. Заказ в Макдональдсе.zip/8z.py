import sys

from PyQt5.QtWidgets import QApplication, QMainWindow
from tastydot import Ui_MainWindow


class MyWidget(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        # self.Cheeseburger_box.text =
        self.wigets = [self.Cheeseburger_box, self.Hamburger_box, self.Cola_box, self.Nuggets_box]
        self.make_order.clicked.connect(self.do_order)

    def do_order(self):
        f_out = "Ваш заказ:" + '\n\r'
        for _ in self.wigets:
            if _.isChecked():
                f_out += _.text() + '\n'
        self.Order.setPlainText(f_out)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())
